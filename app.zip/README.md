# App ToDo
Aplicativo de tarefas a fazer, desenvolvido em Ionic
