import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
})
export class Tab4Page implements OnInit {
  // submitForm(){    
  //   if("" == ''){
  //      alert ({
  //       header: 'Aviso',
  //       message: 'Preencha o campo Título!',
  //       buttons: ['OK']
  //     });
  //     alert();
  //   }
  // }

  constructor() { }

  ngOnInit() {
  }

}
